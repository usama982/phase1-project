<div class="row">
		 <div class="col-sm-12" >
		 <nav class="navbar navbar-inverse" style="margin-top:10px" style="word-spacing:10%"  >
			<div class="container-fluid" style="border:1px solid white">
			<div class="navbar-header">
				<a class="navbar-brand" href="home.html">NY sports</a>
			</div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li><a href="aboutus.php">AboutUS</a></li>
      <li><a href="products.php">products</a></li>
	  <li><a href="Contactus.php">Contact US</a></li>	
	</ul>
  </div>
</nav>
</div>
</div>