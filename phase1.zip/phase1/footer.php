<div class="container">
	<div class="row">
	<div class="col-sm-12">
	<div  class="footer">
	<a href="https://wwww.usamaqayyum862@gmail.com"><i class="material-icons" style="font-size:48px;">email</i>
	<a href="https://www.facebook.com/NY-Sports-1107366592727449/"><i class="material-icons" style="font-size:48px;">facebook</i>
		 
	</div>
	</div>
	</div>
	</div>
	