<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
.container{
margin-top:5%;
}
.footer {
border:1px solid black;
width:97%;
margin-bottom:5%;
}
</style>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">



  </head>
  <body>
     <?php include'logo.php';?>
  
		<?php include'navbar.php'?>
	<div class="container">
	<div class="row">
	<div class="col-sm-8">
	<h1>About Us</h1>
	<pre>We sell quality new and used sports and fitness equipment for cash. We have the best prices in town.
	</pre>
	</div>
	</div>
	</div>
	
	<?php include'footer.php'?>
	</body>
</html>

		 
		 
		 </div>
		 
  
  
  </body>
</html>