<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
.container{
margin-top:5%;
}
.footer {
border:1px solid black;
width:97%;
margin-bottom:5%;
}
</style>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  
  
  
  


  </head>
  <body>
    <?php include'logo.php';?>
  
		<?php include'navbar.php'?>	
		
	<div class="container">
	<div class="row">
	<div class="col-sm-6">
	<a href="productdetails.html">
	<table>
	<tr>
	<td style="padding-left:15%">
    
	
	<a href="p1.html" ><img id="image1" src="images/mens jacket.jpg" height="140px" width="120px" title="mens jacket" ><b>mens jacket</b></a>
	</td>
	<td style="padding-left: 20%">
	<a href="p2.html" ><img id="image2" src="images/gloves.jpg" height="140px" width="120px" title="gloves" ><b>gloves</b></a>
	</td>
	<td style="padding-left:30%"> 
	<a href="p3.html" ><img id="image3" src="images/mountainbikes.jpg" height="140px" width="120px" title="mountainbikes"  ></a><b>mountainbikes</b>
	</td>
	</table>
	</div>
	</div>
	
	<div class="row">
	<div class="col-sm-6">
	<table>
	<tr>
	<td style="padding-left:15%">
	<a href="p4.html" ><img src="images/wear.jpg" height="140px" width="120px" title="woman wear"></a><b>women wear</b>
	</td>
	<td style="padding-left: 25%">
	<a href="p5.html" ><img src="images/hodie.jpg" height="140px" width="120px" title="hoddie"></a><b>hoddie</b>
	</td>
	<td style="padding-left: 30%"> 
	<a href="p6.html" ><img src="images/track.jpg" height="140px" width="120px" title="track"></a><b>track suit</b>
	</td>
	
	
	</table>
	</div>
	</div>
	</a>
	
	
	
	
	
	
	
	
	
	
	</div>
	<?php include'footer.php'?>
	
	</body>
</html>

		 
		 
		 </div>
		 
  
  
  </body>
</html>