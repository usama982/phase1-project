<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
.container{
margin-top:5%;
}
#address{
   padding-top:5%;
   text-align:right;
   padding-right:5px;
   border:1px solid black;
   
   
}
.col-sm-8 p{

width:50% 
padding-right:20%;
margin-left:70%;
padding-bottom:30%;
marign-right:30%;

}
.footer{
border:1px solid black;
width:97%;
margin-bottom:5%;
}

</style>

</script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


  </head>
  <body>
     <?php include'logo.php';?>
  
		<?php include'navbar.php'?>	
	

	<div class="container-fluid">
    <div class="row">
	<div class= "col-sm-8">
	
   <h1>Contact Us</h2>
  <form id="myform" method="post" action="script type=text/js" >
     Name: <input type="text" name="firstname" placeholder="Enter Your name " maxlength="20"/><BR>
	 <br>
     Email: <input type="email" name="email" placeholder="Enter Your email " maxlength="25"/><BR> 
	 <br>
	 Phone: <input type="tel" name="telephone number" placeholder="Enter Your phone" maxlength="12"/><BR>
	 <br>
	 Role: <input type="radio" name="student"  value="selection"/>student
	      <input type="radio" name="student"  value="teacher"/>teacher<br>
	 <br>
	 City:<select>
			<option value="lahore">lahore</option>
			<option value="karachi">karachi</option>
			<option value="peshawar">peshawar</option>
			<option value="kpk">kpk</option>
            <option value="ISlamabad">lslamabad</option>			
	 </select><br>
	 Message:
	 <br>
	<textarea name="messages" rows="4" col="100" style="resize:none" style=width:5/></textarea><br>
	 <input type="button" name="submit button" value="submit" Onclick="validation()"/>
	 </form>  

	 
		 
	</div>
     <div class="col-sm-3" style="padding-left:20%" style="margin-left:10%">
	 <p >main bouleward near yateem khana multan road lahore</p>
	 </div>
	 <div class="col-sm-3" style="padding-left:20%" style="margin-left:10%">
     <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3400.688162100631!2d74.28267221454064!3d31.532723653688272!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919031584da8ee5%3A0x7a20a453329dd5e3!2sMCB+Bank!5e0!3m2!1sen!2ses!4v1507640129886" width="150" height="200" frameborder="0" style="border:0" allowfullscreen></iframe></p>
     


	 </div>
	 
	</div>
	</div>
	

	<?php include'footer.php'?>
	</body>
</html>

		 
		 
		 </div>
		 
  
  
  </body>
</html>