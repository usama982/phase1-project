
<div class="container" style="border:1px solid black">
		<div class="row">
		 <div class="col-sm-8">
		 <img src="images/logo.png" height="65px" width="60px" style="margin-top:10px" style="border:1px solid black">
		 </div>
		 
		 <div class="col-sm-4" style="width:30px" style="height:20px">
		 <a href="https://wwww.usamaqayyum862@gmail.com"><i class="material-icons" style="font-size:48px;">email</i>
		 
		 <div class="row">
		 <div class="col-sm-11">
		 <a href="https://www.facebook.com/NY-Sports-1107366592727449/"><i class="material-icons" style="font-size:48px;">facebook</i>
		 
		 </div>
		 </div>
		 </div>
		 </div>
