<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
.container{
margin-top:5%;
}
.footer {
border:1px solid black;
width:97%;
margin-bottom:5%;
}

</style>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">



  </head>
  <body>
        <?php include'logo.php';?>
  
		<?php include'navbar.php';?>
		
<div class="container-fluid" style="border:1px solid black" style="padding-top:20%">
<div class="row">
  <div class="col-sm-6">
  <h2 class="w3-center"></h2>

<div class="w3-content w3-section" style="max-width:200px" style="padding-right:20%" >
  <img class="mySlides" src="images/m1.jpg" style="width:100%">
  <img class="mySlides" src="images/m3.jpg" style="width:100%">
  <img class="mySlides" src="images/w1.jpg" style="width:100%">
  <img class="mySlides" src="images/slimfit.jpg" style="width:100%">	
  <img class="mySlides" src="images/nike.jpg" style="width:100%">
  </div>
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}	
</script>

</div>
</div>
<div class="container">
 <div class="row">
 <div class="col-sm-8">
	<center><h1>NY sports</h1></center> 
    <pre>We sell quality new and used sports and fitness equipment for cash. We have the best prices in town.<br>we have items with affordable price</pre>
</div>
</div>
</div>
	
	<div class="container">
	<div class="row">
	<div class="col-sm-4">
	<h2>Latest products</h2>
	<table style="text-align:center">
	 <tr>
	 <td>
	 <img src="images/slimfit.jpg" height="95px" width="120px" title="slimfit"><b>slimfit</b>
	 </td>
	 <td style="padding-left:30%">
	 <img src="images/m1.jpg" height="95px" width="120px" title="men"><b>workout</b>
	 </td>
	 <td style="padding-left:45%">
	 <img src="images/w1.jpg" height="95px" width="120px" title="women"><b>hoddies</b>
	 </td>
	 </tr>
	
	</table>
	</div>
	</div>
	</div>
	
	
	<?php include'footer.php'?>
	</body>
</html>

		 
		 
		 </div>
		 
  
  
  </body>
</html>